package com.example.a20194111quiz;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.content.DialogInterface;
import androidx.appcompat.app.AlertDialog;

public class MenuActivity extends AppCompatActivity {

    //로그인 여부 표시를 위해 SharedPreferences 사용.
    private SharedPreferences sharedPreferences;
    private Button loginBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // 액션바 숨기기
        if (getSupportActionBar() != null) {
            getSupportActionBar().hide();
        }
        setContentView(R.layout.activity_menu);

        //로그인 버튼
        loginBtn = findViewById(R.id.loginBtn);
        sharedPreferences = getSharedPreferences("LoginPrefs", MODE_PRIVATE);

        updateLoginButton();  // 로그인 버튼 텍스트 업데이트

        loginBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                boolean isLoggedIn = sharedPreferences.getBoolean("isLoggedIn", false); // 로그인 상태 확인
                if (isLoggedIn) {
                    SharedPreferences.Editor editor = sharedPreferences.edit();
                    editor.putBoolean("isLoggedIn", false);
                    editor.apply();
                    showLogoutDialog();
                    loginBtn.setText("로그인");
                } else {
                    Intent intent = new Intent(MenuActivity.this, LoginActivity.class);
                    startActivity(intent);
                }
            }
        });

        //학습하기 버튼
        Button learnBtn = findViewById(R.id.learningBtn);
        learnBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                boolean isLoggedIn = sharedPreferences.getBoolean("isLoggedIn", false); // 로그인 상태 확인
                if (isLoggedIn){
                    Intent intent = new Intent(MenuActivity.this, MainActivity.class);
                    startActivity(intent);
                }

                else {
                    showLoginPleaseDialog();
                }
            }
        });

        //오답노트 버튼
        Button wrongBtn = findViewById(R.id.WrongNoteBtn);
        wrongBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                boolean isLoggedIn = sharedPreferences.getBoolean("isLoggedIn", false); // 로그인 상태 확인
                if (isLoggedIn){
                    //Intent intent = new Intent(MenuActivity.this, MainActivity.class);
                    //startActivity(intent);
                }

                else {
                    showLoginPleaseDialog();
                }
            }
        });

        //종료 버튼
        Button escapeBtn = findViewById(R.id.escapeBtn);
        escapeBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 앱 종료
                finishAffinity();
            }
        });
    }

    //로그인 상태 업데이트
    private void updateLoginButton() {
        boolean isLoggedIn = sharedPreferences.getBoolean("isLoggedIn", false);
        if (isLoggedIn) {
            loginBtn.setText("로그아웃");
        } else {
            loginBtn.setText("로그인");
        }
    }

    //로그아웃 버튼 클릭
    private void showLogoutDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage("로그아웃 합니다.")
                .setPositiveButton("확인", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                    }
                });
        AlertDialog alert = builder.create();
        alert.show();
    }

    //로그인 없이 학습메뉴, 오답노트 접근 시
    private void showLoginPleaseDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage("로그인 후 이용 가능합니다.")
                .setPositiveButton("확인", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                    }
                });
        AlertDialog alert = builder.create();
        alert.show();
    }
}

