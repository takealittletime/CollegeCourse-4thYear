package com.example.a20194111quiz;

import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import androidx.appcompat.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import android.content.SharedPreferences;

public class LoginActivity extends AppCompatActivity {

    // 입력된 ID
    private EditText editID;

    // 입력된 PW
    private EditText editPassword;

    // 로그인 버튼
    private Button login;
    // 로그인 상태
    private SharedPreferences sharedPreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // 액션바 숨기기
        if (getSupportActionBar() != null) {
            getSupportActionBar().hide();
        }
        setContentView(R.layout.activity_login);

        // SharedPreferences 초기화
        sharedPreferences = getSharedPreferences("LoginPrefs", MODE_PRIVATE);

        editID = findViewById(R.id.editID);
        editPassword = findViewById(R.id.editPassword);
        login = findViewById(R.id.loginbutton);

        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String id = editID.getText().toString();
                String pw = editPassword.getText().toString();

                if (id.equals("tmp") && pw.equals("1234")) {
                    SharedPreferences.Editor editor = sharedPreferences.edit();
                    editor.putBoolean("isLoggedIn", true);
                    editor.apply();

                    showSuccessDialog();
                } else {
                    Toast.makeText(LoginActivity.this, "로그인 실패", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private void showSuccessDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage("로그인 성공!")
                .setPositiveButton("확인", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        Intent intent = new Intent(LoginActivity.this, MenuActivity.class);
                        startActivity(intent);
                        finish(); // LoginActivity를 종료하여 뒤로가기 시 다시 나타나지 않게 함
                    }
                });
        AlertDialog alert = builder.create();
        alert.show();
    }
}
