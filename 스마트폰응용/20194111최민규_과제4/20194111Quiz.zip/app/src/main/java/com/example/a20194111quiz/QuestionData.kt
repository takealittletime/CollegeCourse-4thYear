package com.example.a20194111quiz

object QuestionData {

    fun getQuestion(): ArrayList<Question>{

        val queList: ArrayList<Question> = arrayListOf()



        val q1 = Question(
            1,
            "나를 믿어!\nYou can (    ) on me.",
            "count",
            "add",
            "total",
            "subtract",
            1
        )

        val q2 = Question(
            1,
            "가는 길에 맥도날드 근처에서 내려줄래요?\n Can you (    ) me at McDonald's on the way?",
            "shoot",
            "break",
            "fall",
            "drop",
            4
        )

        val q3 = Question(
            1,
            "걔가 케첩 덩어리(들)에 뒤덮여 있는 걸 발견했어.\nI found him covered in (    ) of ketchub.",
            "pieces",
            "cups",
            "globs",
            "shapes",
            3
        )

        val q4 = Question(
            1,
            "연애는 이제 지겨워. 빨리 결혼하고싶어.\nI'm (     ) dating. I want to get married already.",
            "tired from",
            "tired of",
            "tired by",
            "tiredin",
            2
        )

        val q5 = Question(
            1,
            "잔소리 하지 마!\n (    ) with me!",
            "Don't stop",
            "Don't fight",
            "Don't start",
            "Don't crush",
            3
        )

        val q6 = Question(
            1,
            " 언젠가 같이 커피 한잔하면서 조언 좀 듣고 싶어요.\n I'd love to grab coffee sometime and (        ) a bit. ",
            "pick your brain",
            "pick up the phone",
            "pick your mouth",
            "free talking",
            1
        )

        val q7 = Question(
            1,
            "놀랍지도 않아. 걔 완전 예측하기 어려운 사람이야.\n I'm not surprised.He's a total (     ).",
            "sweetie",
            "flake",
            "baby",
            "pool",
            2
        )

        val q8 = Question(
            1,
            "좋습니다! 자, 우리 어디까지 얘기했었죠?\nGreat! Now, (        )?",
            "where are you",
            "where are their",
            "where were we",
            "where is she",
            3
        )

        val q9 = Question(
            1,
            "좋은 점수를 좀 얻으려고 그러는거야?\nAre you trying to earn some (       )?",
            "brownie points",
            "golden ball",
            "money",
            "match point",
            1
        )

        val q10 = Question(
            1,
            "그럴 가능성이 거의 없지!\n(     ) of that!",
            "Ban",
            "Forbidden",
            "Can't",
            "Fat chance",
            4
        )

        queList.add(q1)
        queList.add(q2)
        queList.add(q3)
        queList.add(q4)
        queList.add(q5)
        queList.add(q6)
        queList.add(q7)
        queList.add(q8)
        queList.add(q9)
        queList.add(q10)

        return queList
    }
}