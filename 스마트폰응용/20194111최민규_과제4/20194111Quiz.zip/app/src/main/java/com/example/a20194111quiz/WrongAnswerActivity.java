package com.example.a20194111quiz;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class WrongAnswerActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_wrong_answer);
    }
}